from flask import render_template, Flask
import json

app = Flask(__name__)


@app.route('/index/<title>')
def index(title):
    return render_template("index.html", title=title)


@app.route('/training/<prof>')
def training(prof):
    prof2 = prof
    if 'врач' in prof2:
        prof2 = 'врач'
    elif 'механик' in prof2:
        prof2 = 'механик'
    else:
        prof2 = 'другое'
    return render_template('trenirovka.html', prof=prof2)


@app.route('/list_prof/<list>')
def list_prof(list):
    naming = 'Инженер-исследователь, ' \
             'Пилот, ' \
             'Строитель, ' \
             'Экзобиолог, ' \
             'Врач, Инженер по терраформированию, ' \
             'Климатолог, Мпециалист по радиационной защите, ' \
             'Астрогеолог, ' \
             'Гляциолог, ' \
             'Инженер жизнеобеспечения, ' \
             'Метеоролог, ' \
             'Оператор марсохода, ' \
             'Киберинженер, Штурман, ' \
             'Пилот дронов'.split(', ')
    return render_template('list_prof.html', list=list, user_list=naming)


@app.route('/answer')
@app.route('/auto_answer')
def answer():
    title = 'Анкета'
    surname = 'Watny'
    name = 'Mark'
    education = 'Выше среднего'
    profession = 'Штурман марсохода'
    sex = 'male'
    motivation = 'Всегда мечтал застрять на Марсе!'
    ready = 'True'
    data = {'Заголовок': title,
            'Фамилия': surname,
            'Имя': name,
            'Образование': education,
            'Профессия': profession,
            'Пол': sex,
            'Мотивация': motivation,
            'Готовы остаться на Марсе?': ready}
    return render_template('answer.html', d=data)


@app.route('/distribution')
def places():
    passangers = ['Ридли Скотт', 'Энди Уир', 'Марк Уотни', 'Венката Капур', 'Тедди Сандерс',
                  'Шон Бин']
    return render_template('distribution.html', passangers=passangers)


@app.route('/member')
def member_function():
    file = open("templates/character.json", mode='r')
    data = json.load(file)
    return render_template('member.html', data=data)


@app.route('/table/<sex>/<int:age>')
def table(sex, age):
    return render_template('table.html', gender=sex, age=age)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
